<html>
    <body>
    <h1> Hello, <?php echo e($biodata ['nama']); ?> </h1>
    <p1> Saya berasal dari kelas <?php echo e($biodata ['kelas']); ?></p2>
    <p2> Hobi saya adalah <?php echo e($biodata ['hobi']); ?></p2>
    <p3> cita cita saya adalah <?php echo e($biodata ['citacita']); ?></p3>
    <h2> Status </h2>
    <p1> Saya sebagai <?php echo e($status ['posisi']); ?> di <?php echo e($status['instansi']); ?> </p2>
    <p2> Sebagai warga negara <?php echo e($status ['warganegara']); ?></p2>
    <p3> dan beragama <?php echo e($status['agama']); ?></p3>
    <h2> Pengalaman </h2>
    <p1> pernah bekerja di <?php echo e($experience ['perusahaan']); ?></p1>
    
    </body>
</html><?php /**PATH C:\xampp\htdocs\example-app\resources\views/latihan1.blade.php ENDPATH**/ ?>