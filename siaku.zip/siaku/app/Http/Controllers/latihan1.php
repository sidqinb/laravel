<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\User;

class latihan1 extends Controller
{
    /**
     * Show the profile for a given user.
     *
     * @param  int  $id
     * @return \Illuminate\View\View
     */
    public function biodata()
    {
        $data['status'] = array('warganegara' => 'Indonesia',
                        'agama' => 'Islam',
                        'instansi' => 'pt alimrugi',
                        'posisi' => 'Direktur');

        $data['biodata']  = array('nama' => 'raihan',
                        'kelas' => 'IK19B',
                        'hobi' => 'ngoding',
                        'citacita' => 'programmer');

        $data['experience'] = array('perusahaan' => 'PT Laknat Abadi Selamanya');
        
        return view('latihan1', $data);
    }
}