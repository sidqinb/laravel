<html>
    <body>
    <h1> Hello, {{ $biodata ['nama'] }} </h1>
    <p1> Saya berasal dari kelas {{ $biodata ['kelas'] }}</p2>
    <p2> Hobi saya adalah {{ $biodata ['hobi'] }}</p2>
    <p3> cita cita saya adalah {{ $biodata ['citacita'] }}</p3>
    <h2> Status </h2>
    <p1> Saya sebagai {{ $status ['posisi'] }} di {{ $status['instansi'] }} </p2>
    <p2> Sebagai warga negara {{ $status ['warganegara'] }}</p2>
    <p3> dan beragama {{ $status['agama'] }}</p3>
    <h2> Pengalaman </h2>
    <p1> pernah bekerja di {{ $experience ['perusahaan']}}</p1>
    
    </body>
</html>