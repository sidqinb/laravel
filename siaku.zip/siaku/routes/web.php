<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\latihan1;
use App\Http\Controllers\HomeController;
use Monolog\Processor\HostnameProcessor;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/greeting', function () {
    return 'welcome';
});


Route::get('/han', function () {
    return 'salam';
});

Route::get('/skuy', function () {
    return 'hanskuy';
});

Route::get('/biodata', function () {
    return view('latihan1', ['name' => 'Eep',
                             'kelas'=> 'IK19B',
                             'hobi' => 'Ngoding',
                             'citacita'=>'progarammer',
                             'posisi' => 'Direktur',
                             'wn' => 'indonesia',
                             'agama' => 'islam']);
});

Route::get('/test1', [latihan1::class, 'biodata']);

Route::get('/dashboard', [HomeController::class, 'index']);


